# L 层 —— 长期记忆

> **类比**：硬盘
> **判据**：存着备用的内容（已经沉淀、可供后续取用）

---

## 容量

**无硬上限** —— 受遗忘曲线约束，而非容量约束。

> 原设计给 N/T/F 各写「30 亿 tokens」、知识库 README 又写
> 2600/700/660 条 —— 两套口径差 6 个数量级。本版**只保留一个概念**：
> L 层没有硬上限，靠遗忘机制自然收敛。

## 存储机制

```
内容被判为「值得沉淀」
（两条路：推理用过 ／ 在 W 层重复 ≥ `m` 次）
    ↓
写入 L 层，带完整标签
    ↓
遵循幂律遗忘曲线
    ↓
use_count ≥ 3 → 升格（追加 role 标签）
    ↓
R < 0.2 且 use_count == 0 → 清理
```

## 遗忘曲线

```
R(t) = a0 · t^(-beta / strength)

  a0       = 0.33      基准保留率
  beta     = 0.132     衰减指数
  t        = 距上次调用的天数
  strength = 巩固度，初始 1.0，每次调用 +0.1
```

| 时间 | 保留率 R |
|---|---|
| 20 分钟 | 0.584 |
| 1 小时 | 0.500 |
| 1 天 | 0.330 |
| 2 天 | 0.280 |
| 6 天 | 0.250 |
| 31 天 | 0.210 |

**清理条件**：`R < 0.2 AND use_count == 0`

> 只有「忘了」**并且**「从没用过」的才删。
> 「记忆时间」= 从未被使用的内容的存活期。

## 标签

L 层内容**必须**带完整标签：

```yaml
role:       [logic, value]    # 用途（数组，第一位权重 1.00 / 第二位 0.60 / 第三位 0.40）
s_weight:   0.85              # 「原话程度」＝加工深度 0~1（1=照别人原话搬来 / 0=自己加工出来的）
                              #   ⚠️ 测「谁给的」，不是「说得多细」：自己编的细节再具体也偏 0
                              #   判据 = 语义相似度（必要） + 生成路径（是否引入额外内容）
                              #   同义改写/换个说法 不算加工（仍判 S）
                              #   作用：感知类（S/N）通道的准入线与排序；判断类池准入不看它
origin:     external          # external | internal
trigger:    input             # input | retrieved
strength:   1.0               # 巩固度
use_count:  0                 # 被调用次数
added:      <timestamp>
```

### `role` 取值

| 值 | 含义 |
|---|---|
| `info` | 暂无用途的素材 |
| `logic` | 推理依据 |
| `value` | 评价标准 |

---

## 检索方式

**不再按目录区分内容** —— 改由标签检索：

| 通道 | 过滤条件（准入） | 阈值 |
|---|---|---|
| **Si**（内倾具体） | `s_weight ≥ 1-focus_Si` | `focus_Si` |
| **Ni**（内倾抽象） | `s_weight < focus_Ni` | `focus_Ni` |
| **Ti**（内倾逻辑） | **`role ∋ logic`**（不看 `s_weight`） | `focus_Ti` |
| **Fi**（内倾价值） | **`role ∋ value`**（不看 `s_weight`） | `focus_Fi` |

排序分 = `相关度 × 位次权重`（感知类通道另按 `s_weight` 调整先后）

> 表中的 `focus_*` 是**派生量** —— 由 8 个功能点（`Se/Si/Ne/Ni/Te/Ti/Fe/Fi`）
> 算出，不是用户直接设置的参数。见 `SKILL.md` §五。

---

## 与原 N/T/F 三库的关系

| 原库 | 合并原因 |
|---|---|
| **N 模块**（判断结果，2600 条） | 生命周期与 T/F **完全相同** |
| **T 模块**（逻辑依据，700 条） | 同上 |
| **F 模块**（情感依据，660 条） | 同上 |

> **为什么合并**：库的物理边界应由**生命周期**决定。三者都是
> 「沉淀 + 遗忘 + 持久化」，区别**只在语义用途** —— 而那是
> **查询条件**，不是**物理分区理由**。

**原「稳定性」标注作废**：

| 原标注 | 处理 |
|---|---|
| N 模块 30 天 | 统一按幂律；「45 天 / 30 天的差异是原程序错误」（用户裁定） |
| T 模块 45 天 | 同上 |
| F 模块 30 天 | 同上 |

---

## 目录内容

```
L/
├── README.md                  ← 本文件
├── mental_models.md           ← 心智模型 10 个（原 N/T 两份合并）
├── frameworks.md              ← 思维框架 12 个（原 T 分析 + 决策两份合并）
├── reasoning_rules.md         ← 推理规则集（因果/相关/层次/时间）
├── insight_fragments.md       ← 洞察片段 + 图景 + 案例（原 N fragments 去重）
├── value_standards.md         ← 价值标准（原 F 两份合并）
├── typhoon_knowledge.md       ← 台风知识（原 N/T/F 三份合并）
└── verification.md            ← 检验准则（预载：怎么判断输入的可信度）
```

## 条目格式

内容文件在文件头用 `defaults` 批量声明公共字段，**逐条只标 `role` 与 `s_weight`**
（准入与排序的唯二必需项）：

````markdown
```yaml
defaults:
  origin: internal
  trigger: retrieved
  strength: 1.0
  use_count: 0
  added: 2026-10-10
```

## 小节标题

`role:logic,value; s:0.20`

- 正文……
````

**例外**：条目与 `defaults` 不同时，就地覆盖（如 `typhoon_knowledge.md` 全篇
`origin: external`；`insight_fragments.md` 的「案例」节单独声明 `origin: external`）。

> **存量内容的 `s_weight` 是估算值** —— 迁移时没有同期思考链可比对，
> 故按**内容来源**代理判定：`origin: external`（外部材料）偏 S，`origin: internal`（自我加工）偏 N。
> 新写入的内容则严格按语义相似度实测（见 `SKILL.md` §四）。
>
> ⚠️ **不要用「具体程度」当代理** —— `s_weight` 测的是**加工深度**，
> 与内容写得具体还是抽象**无关**（详见 `SKILL.md` §四「s_weight 只读一个轴」）。

## 迁移对照

| 原文件 | 新文件 |
|---|---|
| `N_module/mental_models.md` + `T_module/mental_model_applications.md` | `mental_models.md` |
| `T_module/analysis_frameworks.md` + `T_module/decision_frameworks.md` | `frameworks.md` |
| `T_module/specific_rules.md` | `reasoning_rules.md` |
| `N_module/fragments.md` | `insight_fragments.md` |
| `F_module/value_standards.md` + `F_module/specific_values.md` | `value_standards.md` |
| `N/T/F_module/tropical_cyclone_*.md`（3 份） | `typhoon_knowledge.md` |

