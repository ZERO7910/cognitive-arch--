# L 层 —— 长期记忆

> **类比**：硬盘
> **存什么**：沉淀下来的内容 —— 可供后续取用、会随时间慢慢遗忘
> **位置**：`knowledge_base/L/`

---

## 一、容量

**无硬上限** —— 受遗忘曲线约束，而非容量约束。

> 旧版曾给 N/T/F 各写「30 亿 tokens」、又另写「2600/700/660 条」——
> 两套口径差 6 个数量级。本版只保留一个概念：
> **L 层没有硬上限，靠遗忘机制自然收敛。**

---

## 二、存储机制

```
内容被判为「值得沉淀」        ← 两条路（见 §六）
    ↓
写入 L 层，带完整标签
    ↓
遵循幂律遗忘曲线（见 §四）
    ↓
use_count ≥ 3 → 升格（追加 role 标签）
    ↓
R < 0.2 且 use_count == 0 → 清理
```

---

## 三、字段定义

**每条内容自带的元数据。** 定义与 `config/cognitive_config.yaml` 的 `labels` 段一致。

| 字段 | 类型 | 含义 |
|---|---|---|
| `weight_S` | 0.0 ~ 1.0 | **S 占比** —— 这条内容里「外界来的部分」占几成。<br>`1.0` = 完全是外界原话（复述、搬运）；`0` = 完全是自己产的（推断、构想）。<br>**作用**：决定它归 S 侧还是 N 侧、以及排序先后。 |
| `weight_T` | 0.0 ~ 1.0 | **T 占比** —— 这条判断依据里「讲道理的部分」占几成。<br>`1.0` = 纯逻辑依据 · `0.0` = 纯情感依据 · 中间值 = 两者都有。<br>**作用**：决定它归逻辑池还是情感池，以及跨池供给时能顶多少。<br>**仅判断依据类需要**：`role: info` 的素材不标此字段。 |
| `role` | `info` / `logic` / `value` | **用途标签** —— 这条内容被当什么用。<br>`logic` = 逻辑依据 · `value` = 情感依据 · `info` = 素材（用途未定） |
| `origin` | `external` / `internal` | **来源** —— `external` = 环境当下给我的 · `internal` = 我自己产出的 |
| `strength` | float | **巩固度**（遗忘曲线用）；初始 `1.0`，每次被调用 `+0.1` |
| `use_count` | int | **被调用次数**；初始 `0` |

> **可选字段** `added`：内容加入 L 层的日期。**仅供追溯，机制不使用** —— 遗忘曲线用的是「距上次调用的天数」，不是加入时间。

### 两条一致性约束

1. **`role` 与 `weight_T` 要自洽** —— `role: logic` 的条目 `weight_T ≥ 0.5`；`role: value` 的条目 `weight_T ≤ 0.5`。
2. **`role: info` 不标 `weight_T`** —— 素材还没定用途，谈不上 T/F 配比。

---

## 四、遗忘曲线

```
R(t) = a0 · t^(−beta / strength)

  a0       = 0.33      基准保留率
  beta     = 0.132     衰减指数
  t        = 距上次调用的天数
  strength = 巩固度，初始 1.0，每次调用 +0.1
```

| 时间 | 保留率 R |
|---|---|
| 20 分钟 | 0.584 |
| 1 小时 | 0.500 |
| 1 天 | 0.330 |
| 2 天 | 0.280 |
| 6 天 | 0.250 |
| 31 天 | 0.210 |

**清理条件**：`R < 0.2 AND use_count == 0`

> 只有「忘了」**并且**「从没用过」的才删。

---

## 五、取用与排序

**按标签检索，不按文件名找。**

```
候选 = 从 W 层 + L 层检索出的内容
    ↓
排序：相关度降序（第一条作 anchor）
    ↓
逐条判：算 sim_angle（公式②）→ 落在 focus_x 区间？（公式①）
```

| 取哪一类 | 调用哪个聚焦度 |
|---|---|
| 外源感知内容（S 侧） | `focus_S` |
| 内源感知内容（N 侧） | `focus_N` |
| 逻辑判断依据 | `focus_T` |
| 情感判断依据 | `focus_F` |

> 表中的 `focus_*` 是**派生量** —— 由 8 个功能强度（`Se/Si/Ne/Ni/Te/Ti/Fe/Fi`）
> 算出，不是用户直接设置的参数。见 `SKILL.md` §三。

---

## 六、沉淀（内容怎么进 L 层）

| 路径 | 触发 | 内容形态 | 状态 |
|---|---|---|---|
| **主动沉淀** | 被用作判断依据 / 产物落盘 | 加工产物（`weight_S` 偏低） | ✅ 生效 |
| **重复沉淀** | 在 W 层反复出现 ≥ `repeat_m` 次 | 未加工（`weight_S` 偏高） | ⏸️ 待定 |

> **「死记忘得快」是机制的自然结果** —— `weight_S` 高的内容取用面窄
> → 很少被调用 → `strength` 不涨 → 按曲线衰减更快。**不需要为它写额外规则。**

---

## 七、条目格式

文件头用 `defaults` 批量声明公共字段，**逐条只标 `role` / `weight_T` / `weight_S`**：

````markdown
```yaml
defaults:
  origin: internal
  strength: 1.0
  use_count: 0
  added: 2026-10-10
```

## 小节标题

`role:logic; weight_T:1.0; weight_S:0.20`

- 正文……
````

**例外**：条目与 `defaults` 不同时，就地覆盖
（如 `typhoon_knowledge.md` 全篇 `origin: external`；`insight_fragments.md` 的「案例」节单独声明 `origin: external`）。

---

## 八、存量内容的标签口径 ⚠️

本目录的 7 个内容文件是**从 v4 迁移**过来的。迁移时做过如下处理：

| 项 | v4（旧） | v5（本版） |
|---|---|---|
| 内容标签 | `s_weight`（测「加工深度」） | **`weight_S`**（测「S 占比」） |
| 用途标签 | `role: [logic, value]`（数组 + 位次权重） | **`role` 单值 ＋ `weight_T` 配比** |
| `trigger` 字段 | 有（`input` / `retrieved`） | **已移除**（v5 不再需要） |

**`role` 数组 → `weight_T` 的折算依据**（沿用 v4 的位次权重 `1.00 / 0.60`）：

| 原 `role` | 新 `role` | 新 `weight_T` |
|---|---|---|
| `[logic]` | `logic` | `1.0` |
| `[value]` | `value` | `0.0` |
| `[logic, value]` | `logic` | `0.6` ← `1.00 / (1.00 + 0.60)` |
| `[value, logic]` | `value` | `0.4` |
| `[logic, info]` | `logic` | `1.0` |
| `[info, …]` | `info` | 不标 |

### 存量 `weight_S` 是**估算值** —— 已知局限

迁移时**没有同期思考链可比对**，故按**内容来源**代理判定：
`origin: external` 偏 S、`origin: internal` 偏 N。

⚠️ **两条限制**：

1. **粒度粗** —— 估算以「节」为单位。同一节里，原样搬运的内容与我的概括解读
   可能共用一个值。**实测跑起来后应按实际观察细化。**
2. **不要用「具体程度」当代理** —— `weight_S` 量的是**来源占比**，
   与内容写得具体还是抽象**无关**（自己编的细节再具体也偏 0）。

**新写入的内容**则严格按 S 占比传递公式（`SKILL.md` §五 公式③）实测，不受此限。

---

## 九、内容清单

```
L/
├── README.md                  ← 本文件
├── mental_models.md           ← 心智模型 10 个
├── frameworks.md              ← 思维框架 12 个
├── reasoning_rules.md         ← 推理规则集（因果 / 相关 / 层次 / 时间）
├── insight_fragments.md       ← 洞察片段 ＋ 图景 ＋ 案例
├── value_standards.md         ← 价值标准（六视角 ＋ 具体标准）
├── typhoon_knowledge.md       ← 台风知识（科学 ＋ 人文 ＋ 社会）
└── verification.md            ← 检验准则（预载：怎么判断输入的可信度）
```

---

## 十、迁移对照（v4 → v5）

| v4 原文件 | v5 文件 | 处理 |
|---|---|---|
| `mental_models.md` | `mental_models.md` | 标签转换 |
| `frameworks.md` | `frameworks.md` | 标签转换 |
| `reasoning_rules.md` | `reasoning_rules.md` | 标签转换 |
| `insight_fragments.md` | `insight_fragments.md` | 标签转换 |
| `value_standards.md` | `value_standards.md` | 标签转换 |
| `typhoon_knowledge.md` | `typhoon_knowledge.md` | 标签转换 |
| `verification.md` | `verification.md` | 标签转换 |

**内容本身全部沿用** —— 未增删条目，仅改标签体系。
